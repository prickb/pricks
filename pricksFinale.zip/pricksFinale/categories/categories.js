const scentedCandles = document.querySelector('#scented__candles');
const stickers = document.querySelector('#stickers');
const notebooks = document.querySelector('#notebooks');
const notepads = document.querySelector('#notepads');
const artPrints = document.querySelector('#art__prints');
const upcoming = document.querySelector('#upcoming');
const scentedCandlesSection = document.querySelector('.scented__candles');
const stickersSection = document.querySelector('.stickers');
const notebooksSection = document.querySelector('.notebooks');
const notepadsSection = document.querySelector('.notepads');
const artPrintsSection = document.querySelector('.art__prints');
const upcomingSection = document.querySelector('.upcoming');


scentedCandles.addEventListener('click', () => {
    addScentedCandles();

});

stickers.addEventListener('click', () => {
    addStickers();

});
notebooks.addEventListener('click', () => {
    addNotebooks();

});
notepads.addEventListener('click', () => {
    addNotepads();

});
artPrints.addEventListener('click', () => {
    addartPrints();

});
upcoming.addEventListener('click', () => {
    addUpcoming();

});



function addScentedCandles() {
    scentedCandlesSection.style.display = "block";
    stickersSection.style.display = "none";
    notebooksSection.style.display = "none";
    notepadsSection.style.display = "none";
    artPrintsSection.style.display = "none";
    upcomingSection.style.display = "none";
}

function addStickers() {
    scentedCandlesSection.style.display = "none";
    stickersSection.style.display = "block";
    notebooksSection.style.display = "none";
    notepadsSection.style.display = "none";
    artPrintsSection.style.display = "none";
    upcomingSection.style.display = "none";
}

function addNotebooks() {
    scentedCandlesSection.style.display = "none";
    stickersSection.style.display = "none";
    notebooksSection.style.display = "block";
    notepadsSection.style.display = "none";
    artPrintsSection.style.display = "none";
    upcomingSection.style.display = "none";
}

function addNotepads() {
    scentedCandlesSection.style.display = "none";
    stickersSection.style.display = "none";
    notebooksSection.style.display = "none";
    notepadsSection.style.display = "block";
    artPrintsSection.style.display = "none";
    upcomingSection.style.display = "none";
}

function addartPrints() {
    scentedCandlesSection.style.display = "none";
    stickersSection.style.display = "none";
    notebooksSection.style.display = "none";
    notepadsSection.style.display = "none";
    artPrintsSection.style.display = "block";
    upcomingSection.style.display = "none";
}

function addUpcoming() {
    scentedCandlesSection.style.display = "none";
    stickersSection.style.display = "none";
    notebooksSection.style.display = "none";
    notepadsSection.style.display = "none";
    artPrintsSection.style.display = "none";
    upcomingSection.style.display = "block";
}