const deets = document.querySelector('#deets');
const orders = document.querySelector('#orders');
const wishlist = document.querySelector('#wishlist');
const deetsSection = document.querySelector('.deets');
const ordersSection = document.querySelector('.orders');
const statusSection = document.querySelector('.status');

deets.addEventListener('click', () => {
    addDeets();
    // deetsSection.classList.remove('hidden');
    // ordersSection.classList.add('hidden');
});

orders.addEventListener('click', () => {
    addOrders();
    // ordersSection.classList.remove('hidden');
    // deetsSection.classList.add('hidden');
});

wishlist.addEventListener('click', () => {
    addWishlist();
});

function addDeets() {
    deetsSection.style.display = "block";
    ordersSection.style.display = "none";
    statusSection.style.display = "none";
}

function addOrders() {
    deetsSection.style.display = "none";
    ordersSection.style.display = "block";
    statusSection.style.display = "none";
}

function addWishlist() {
    deetsSection.style.display = "none";
    ordersSection.style.display = "none";
    statusSection.style.display = "block";
}