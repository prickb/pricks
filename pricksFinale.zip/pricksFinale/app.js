//BESTSELLER
const bestseller = document.querySelector('.bestseller');
let screenWidth = window.innerWidth;
console.log(screenWidth);
if ((screenWidth > 600) && (screenWidth <= 833)) {
    bestseller.innerHTML = 'BESTSELLERS BESTSELLERS BESTSELLERS';
}
else if ((screenWidth > 833) && (screenWidth <= 1200)) {
    bestseller.innerHTML = 'BESTSELLERS BESTSELLERS BESTSELLERS BESTSELLERS';
}
else {
    bestseller.innerHTML = 'BESTSELLERS BESTSELLERS BESTSELLERS BESTSELLERS BESTSELLERS BESTSELLERS';
}

function AutoRefresh(t) {
    setTimeout("location.reload(true);", t);
}


const previous = document.querySelector('.previous');
const next = document.querySelector('.next');
const newNavPre = document.querySelector('.new_nav__pre');
const newNavNext = document.querySelector('.new_nav__next');
const images = document.querySelector('.product__image__slider').children;
const productDescription = document.querySelector('.product__description').children;
const totalImages = images.length;
const productInfo = productDescription.length;
let currentIndex = 0;

previous.addEventListener('click', () => {
    console.log("previous")
    previousImage();
})

next.addEventListener('click', () => {
    console.log("next")
    nextImage();
})

newNavPre.addEventListener('click', () => {
    newPreviousImage();
    console.log("new prev");
})

newNavNext.addEventListener('click', () => {
    newNextImage();
    console.log("new next");
})

function nextImage() {
    images[currentIndex].classList.remove('main');
    productDescription[currentIndex].classList.remove('main');
    if (currentIndex == totalImages - 1) {
        currentIndex = 0;
    }
    else {
        currentIndex++;
    }
    images[currentIndex].classList.add('main');
    productDescription[currentIndex].classList.add('main');
}

function previousImage() {
    images[currentIndex].classList.remove('main');
    productDescription[currentIndex].classList.remove('main');
    if (currentIndex == 0) {
        currentIndex = totalImages - 1;
    }
    else {
        currentIndex--;
    }
    images[currentIndex].classList.add('main');
    productDescription[currentIndex].classList.add('main');
}

const newImagesSlider = document.querySelector('.new__images');
const newImage = document.querySelector('.new__images').children;

function newPreviousImage() {
    newImagesSlider.prepend(newImage[newImage.length - 1]);
}

function newNextImage() {
    newImagesSlider.append(newImage[0]);
}



//POPUP
const popup = document.querySelector('.popup');

window.addEventListener('load', () => {
    showPopup();
})

function showPopup() {
    const timeLimit = 5;
    let i = 0;
    const timer = setInterval(() => {
        i++;
        if (i == timeLimit) {
            clearInterval(timer);
            popup.classList.add('show');
        }
        console.log(i);
    }, 1000)
    window.onclick = (event) => {
        if (!event.target.matches('.popup__box')) {
            if (popup.classList.contains('show')) {
                popup.classList.remove('show');
                console.log("remove")
            }
        }
    }
}



// const categoriesSection = document.querySelector('.categories__section');
const prickliness = document.querySelector('#prickliness');
const upcoming = document.querySelector('#upcoming');
const reviews = document.querySelector('#reviews');
const prick = document.querySelector('#prick');
const categoriesLi1 = document.querySelector('.categories__li--1');
const categoriesLi2 = document.querySelector('.categories__li--2');
const categoriesLi3 = document.querySelector('.categories__li--3');
const categoriesLi4 = document.querySelector('.categories__li--4');
const upcomingSection = document.querySelector('.categories__upcoming');
const pricklinessSection = document.querySelector('.categories__prickliness');
const reviewSection = document.querySelector('.categories__review');


prickliness.addEventListener('click', () => {
    addprickliness();
});

upcoming.addEventListener('click', () => {
    addupcoming();
});

reviews.addEventListener('click', () => {
    addreview();
});

function addprickliness() {
    pricklinessSection.style.display = "block";
    upcomingSection.style.display = "none";
    reviewSection.style.display = "none";
}

function addupcoming() {
    pricklinessSection.style.display = "none";
    upcomingSection.style.display = "flex";
    reviewSection.style.display = "none";
}

function addreview() {
    pricklinessSection.style.display = "none";
    upcomingSection.style.display = "none";
    reviewSection.style.display = "block";
}


const shopBtn = document.querySelector('.shop');
const shopCategories = document.querySelector('.shop__categories');
let timeoutId;

shopBtn.addEventListener('mouseover', () => {
    clearTimeout(timeoutId);
    shopCategories.style.display = 'block';
    shopBtn.style.backgroundColor = '#f5efda';
    shopBtn.style.color = '#494850';
});

shopBtn.addEventListener('mouseout', () => {
    timeoutId = setTimeout(() => {
        shopCategories.style.display = 'none';
        shopBtn.style.backgroundColor = 'transparent';
        shopBtn.style.color = '#f5efda';
    }, 2000);
});

document.addEventListener('click', (event) => {
    if (event.target !== shopBtn && event.target !== shopCategories) {
        shopCategories.style.display = 'none';
        shopBtn.style.backgroundColor = 'transparent';
        shopBtn.style.color = '#f5efda';
    }
});
