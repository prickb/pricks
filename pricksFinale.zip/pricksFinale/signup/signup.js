function validateForm() {
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var email = document.getElementById("email").value;
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var isValid = true;

    if (!firstName.trim()) {
        document.getElementById("firstNameError").innerText = "First Name is required";
        isValid = false;
    } else {
        document.getElementById("firstNameError").innerText = "";
    }

    if (!lastName.trim()) {
        document.getElementById("lastNameError").innerText = "Last Name is required";
        isValid = false;
    } else {
        document.getElementById("lastNameError").innerText = "";
    }

    if (!email.trim()) {
        document.getElementById("emailError").innerText = "Email is required";
        isValid = false;
    } else if (!isValidEmail(email)) {
        document.getElementById("emailError").innerText = "Invalid email format";
        isValid = false;
    } else {
        document.getElementById("emailError").innerText = "";
    }

    if (!username.trim()) {
        document.getElementById("usernameError").innerText = "Username is required";
        isValid = false;
    } else {
        document.getElementById("usernameError").innerText = "";
    }

    if (!password.trim()) {
        document.getElementById("passwordError").innerText = "Password is required";
        isValid = false;
    } else {
        document.getElementById("passwordError").innerText = "";
    }

    if (!confirmPassword.trim()) {
        document.getElementById("confirmPasswordError").innerText = "Confirm Password is required";
        isValid = false;
    } else if (password !== confirmPassword) {
        document.getElementById("confirmPasswordError").innerText = "Passwords do not match";
        isValid = false;
    } else {
        document.getElementById("confirmPasswordError").innerText = "";
    }

    return isValid;
}

function isValidEmail(email) {
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}