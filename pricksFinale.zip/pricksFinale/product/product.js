const cartIcon = document.querySelector('.cart__icon');
const cartItems = document.querySelector('.cart__items');
let timeoutId;

cartIcon.addEventListener('mouseover', () => {
    clearTimeout(timeoutId);
    cartItems.style.display = 'block';
});

cartIcon.addEventListener('mouseout', () => {
    timeoutId = setTimeout(() => {
        cartItems.style.display = 'none';
    }, 2000);
});

document.addEventListener('click', (event) => {
    if (event.target !== cartIcon && event.target !== cartItems) {
        cartItems.style.display = 'none';
    }
});



const previous = document.querySelector('.product__cart--prebtn');
const next = document.querySelector('.product__cart--nextbtn');
const images = document.querySelector('.product__image__slider').children;
const totalImages = images.length;
let currentIndex = 0;

previous.addEventListener('click', () => {
    console.log("previous");
    previousImage();
})

next.addEventListener('click', () => {
    console.log("next");
    nextImage();
})

function nextImage() {
    images[currentIndex].classList.remove('main');
    if (currentIndex == totalImages - 1) {
        currentIndex = 0;
    }
    else {
        currentIndex++;
    }
    images[currentIndex].classList.add('main');
}

function previousImage() {
    images[currentIndex].classList.remove('main');
    if (currentIndex == 0) {
        currentIndex = totalImages - 1;
    }
    else {
        currentIndex--;
    }
    images[currentIndex].classList.add('main');
}
